import { createClient } from '@/lib/supabase/server'
import { StatsCards } from '@/components/dashboard/stats-cards'
import { RecentProducts } from '@/components/dashboard/recent-products'
import { QuickActions } from '@/components/dashboard/quick-actions'
import { LowStockAlert } from '@/components/dashboard/low-stock-alert'
import type { Product, DashboardStats } from '@/lib/types'

async function getDashboardData(): Promise<{ products: Product[]; stats: DashboardStats; lowStockProducts: Product[] }> {
  const supabase = await createClient()
  
  const { data: products, error } = await supabase
    .from('aruna_farma')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching products:', error)
    return {
      products: [],
      stats: {
        totalProducts: 0,
        totalValue: 0,
        lowStockCount: 0,
        outOfStockCount: 0,
      },
      lowStockProducts: [],
    }
  }

  const productList = products || []
  const lowStockProducts = productList.filter(p => p.stok <= 10).sort((a, b) => a.stok - b.stok)
  
  const stats: DashboardStats = {
    totalProducts: productList.length,
    totalValue: productList.reduce((acc, p) => acc + (p.harga * p.stok), 0),
    lowStockCount: productList.filter(p => p.stok > 0 && p.stok <= 10).length,
    outOfStockCount: productList.filter(p => p.stok === 0).length,
  }

  return { products: productList, stats, lowStockProducts }
}

export default async function DashboardPage() {
  const { products, stats, lowStockProducts } = await getDashboardData()

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Selamat datang di Aruna Farma Enterprise Platform
          </p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-success/10 border border-success/20">
          <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
          <span className="text-sm font-medium text-success">Sistem Online</span>
        </div>
      </div>

      {/* Stats Cards */}
      <StatsCards stats={stats} />

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent Products - Takes 2 columns */}
        <div className="lg:col-span-2">
          <RecentProducts products={products.slice(0, 8)} />
        </div>
        
        {/* Right Column */}
        <div className="space-y-6">
          <QuickActions />
          <LowStockAlert products={lowStockProducts.slice(0, 5)} />
        </div>
      </div>
    </div>
  )
}
