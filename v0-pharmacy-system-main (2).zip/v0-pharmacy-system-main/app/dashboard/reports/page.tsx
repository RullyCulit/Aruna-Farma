import { createClient } from '@/lib/supabase/server'
import { ReportsOverview } from '@/components/dashboard/reports-overview'
import type { Product } from '@/lib/types'

async function getProducts(): Promise<Product[]> {
  const supabase = await createClient()
  
  const { data: products, error } = await supabase
    .from('aruna_farma')
    .select('*')
    .order('nama_obat', { ascending: true })

  if (error) {
    console.error('Error fetching products:', error)
    return []
  }

  return products || []
}

export default async function ReportsPage() {
  const products = await getProducts()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Laporan Inventaris</h1>
        <p className="text-muted-foreground">Analisis dan ringkasan data produk</p>
      </div>

      <ReportsOverview products={products} />
    </div>
  )
}
