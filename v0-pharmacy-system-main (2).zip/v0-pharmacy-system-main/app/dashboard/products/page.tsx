import { createClient } from '@/lib/supabase/server'
import { ProductsTable } from '@/components/dashboard/products-table'
import { ProductsHeader } from '@/components/dashboard/products-header'
import type { Product } from '@/lib/types'

const PAGE_SIZE = 25

async function getProducts(): Promise<{ products: Product[]; totalCount: number }> {
  const supabase = await createClient()
  
  const { data: products, count, error } = await supabase
    .from('aruna_farma')
    .select('*', { count: 'exact' })
    .order('nama_obat', { ascending: true })
    .range(0, PAGE_SIZE - 1)

  if (error) {
    console.error('Error fetching products:', error)
    return { products: [], totalCount: 0 }
  }

  return { products: products || [], totalCount: count || 0 }
}

export default async function ProductsPage() {
  const { products, totalCount } = await getProducts()

  return (
    <div className="space-y-6">
      <ProductsHeader totalProducts={totalCount} />
      <ProductsTable initialProducts={products} totalCount={totalCount} />
    </div>
  )
}
