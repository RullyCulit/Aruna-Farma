'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { AlertCircle, Loader2, Pill, Eye, EyeOff, Shield, CheckCircle2 } from 'lucide-react'

const ADMIN_EMAIL = 'admin@arunafarma.com'
const ADMIN_PASSWORD = 'ArunaFarma#2026'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [adminStatus, setAdminStatus] = useState<'checking' | 'creating' | 'ready'>('checking')
  const router = useRouter()

  useEffect(() => {
    async function ensureAdminExists() {
      const supabase = createClient()
      
      // Try to sign in as admin to check if account exists
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
      })

      if (signInError) {
        // Admin doesn't exist, create it
        setAdminStatus('creating')
        const { error: signUpError } = await supabase.auth.signUp({
          email: ADMIN_EMAIL,
          password: ADMIN_PASSWORD,
          options: {
            data: {
              role: 'admin',
              full_name: 'Administrator',
            },
          },
        })

        if (signUpError && !signUpError.message.includes('already registered')) {
          console.error('Failed to create admin:', signUpError)
        }
        
        // Sign out after checking/creating
        await supabase.auth.signOut()
      } else {
        // Admin exists, sign out
        await supabase.auth.signOut()
      }
      
      setAdminStatus('ready')
    }

    ensureAdminExists()
  }, [])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      if (error.message.includes('Invalid login credentials')) {
        setError('Email atau password salah')
      } else if (error.message.includes('Email not confirmed')) {
        setError('Email belum dikonfirmasi. Silakan cek inbox email Anda.')
      } else {
        setError(error.message)
      }
      setLoading(false)
      return
    }

    router.push('/dashboard')
    router.refresh()
  }

  const fillAdminCredentials = () => {
    setEmail(ADMIN_EMAIL)
    setPassword(ADMIN_PASSWORD)
  }

  return (
    <div className="min-h-screen flex items-center justify-center gradient-bg p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-primary/10 blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-accent/10 blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo and branding */}
        <div className="text-center mb-8 animate-float">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/20 border border-primary/30 glow-primary mb-6">
            <Pill className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-gradient mb-2">Aruna Farma</h1>
          <p className="text-muted-foreground text-sm">Enterprise Platform</p>
        </div>

        {/* Login card with glassmorphism */}
        <div className="glass-card rounded-3xl p-8">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold text-foreground mb-1">Selamat Datang</h2>
            <p className="text-sm text-muted-foreground">Masuk ke sistem manajemen apotek</p>
          </div>

          {/* Admin status indicator */}
          {adminStatus !== 'ready' && (
            <div className="flex items-center gap-2 rounded-xl bg-primary/10 border border-primary/20 p-3 mb-6">
              <Loader2 className="h-4 w-4 animate-spin text-primary" />
              <span className="text-sm text-primary">
                {adminStatus === 'checking' ? 'Memeriksa sistem...' : 'Menyiapkan akun admin...'}
              </span>
            </div>
          )}

          {adminStatus === 'ready' && (
            <div className="flex items-center gap-2 rounded-xl bg-success/10 border border-success/20 p-3 mb-6">
              <CheckCircle2 className="h-4 w-4 text-success" />
              <span className="text-sm text-success">Sistem siap</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            {error && (
              <div className="flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
                <AlertCircle className="h-4 w-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground/80">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="nama@arunafarma.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={loading || adminStatus !== 'ready'}
                className="h-12 rounded-xl bg-input/50 border-border/50 focus:border-primary focus:ring-primary/20 placeholder:text-muted-foreground/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground/80">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Masukkan password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={loading || adminStatus !== 'ready'}
                  className="h-12 rounded-xl bg-input/50 border-border/50 focus:border-primary focus:ring-primary/20 placeholder:text-muted-foreground/50 pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-semibold transition-all hover:glow-primary" 
              disabled={loading || adminStatus !== 'ready'}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Memproses...
                </>
              ) : (
                'Masuk'
              )}
            </Button>
          </form>

          {/* Admin quick login */}
          <div className="mt-6 pt-6 border-t border-border/30">
            <button
              type="button"
              onClick={fillAdminCredentials}
              disabled={adminStatus !== 'ready'}
              className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors disabled:opacity-50"
            >
              <Shield className="h-4 w-4" />
              Login sebagai Admin
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-xs text-muted-foreground/60">
            Aruna Farma Enterprise Platform v1.0
          </p>
          <p className="text-xs text-muted-foreground/40 mt-1">
            Powered by Supabase
          </p>
        </div>
      </div>
    </div>
  )
}
